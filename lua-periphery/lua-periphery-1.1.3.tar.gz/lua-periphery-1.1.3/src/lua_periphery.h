/*
 * lua-periphery by vsergeev
 * https://github.com/vsergeev/lua-periphery
 * License: MIT
 */

#ifndef _LUA_PERIPHERY_H
#define _LUA_PERIPHERY_H

#define LUA_PERIPHERY_VERSION           "1.1.3"

#endif

